const { iso2ToIso3 } = require('./iso3166')

function requiredEnv(name) {
  const v = String(process.env[name] || '').trim()
  if (!v) throw new Error(`${name} is not configured`)
  return v
}

function getBaseUrl() {
  return (process.env.YASSIR_BASE_URL || 'https://stg-api.payment.yassir.io').replace(/\/$/, '')
}

function getCheckBaseUrl() {
  return (process.env.YASSIR_CHECK_BASE_URL || process.env.YASSIR_BASE_URL || 'https://epayment-core-stg.yassir.io').replace(/\/$/, '')
}

function getAuthHeader() {
  const clientId = requiredEnv('YASSIR_CLIENT_ID')
  const clientSecret = requiredEnv('YASSIR_CLIENT_SECRET')
  const token = Buffer.from(`${clientId}:${clientSecret}`, 'utf8').toString('base64')
  return `Bearer ${token}`
}

function deriveServiceFromBody(body) {
  if (!body || typeof body !== 'object') return ''
  const customerId = String(body.customerId || body.userId || '').trim()
  const m = /EXT_([A-Z0-9]+)\./i.exec(customerId)
  return m && m[1] ? String(m[1]).toUpperCase() : ''
}

function deriveServiceFromEnv() {
  const clientId = String(process.env.YASSIR_CLIENT_ID || '').trim()
  if (!clientId) return ''
  const m = /EXT_([A-Z0-9]+)\./i.exec(clientId)
  return m && m[1] ? String(m[1]).toUpperCase() : ''
}

function deriveCountryCodeFromBody(body) {
  if (!body || typeof body !== 'object') return ''
  const v = String(body.countryCode || body.actionCountryCode || body.country || body.country_code || '').trim()
  return v
}

async function yassirRequest(method, path, { query, body, extraHeaders, baseUrlOverride } = {}) {
  const baseUrl = baseUrlOverride || getBaseUrl()
  const u = new URL(baseUrl + path)
  if (query) {
    for (const [k, v] of Object.entries(query)) {
      if (v == null) continue
      u.searchParams.set(k, String(v))
    }
  }

  const platform = String(process.env.YASSIR_PLATFORM || 'API').trim().toUpperCase() || 'API'
  const envService = String(process.env.YASSIR_SERVICE || process.env.YASSIR_X_SERVICE || '').trim()
  const service = envService || deriveServiceFromBody(body) || deriveServiceFromEnv() || 'PAYMENT'
  const sdkVersion = String(process.env.YASSIR_SDK_VERSION || '').trim()
  const countryHeader = deriveCountryCodeFromBody(body)

  const headers = {
    accept: 'application/json',
    authorization: getAuthHeader(),
    'x-platform': platform,
    'x-service': service,
    ...extraHeaders,
  }
  if (!extraHeaders || !extraHeaders['x-country-code']) {
    if (countryHeader) headers['x-country-code'] = countryHeader
  }
  if (platform !== 'API' && sdkVersion) {
    headers['x-sdk-version'] = sdkVersion
  }
  let payload
  if (body !== undefined) {
    headers['content-type'] = 'application/json'
    payload = JSON.stringify(body)
  }

  const res = await fetch(u.toString(), { method, headers, body: payload })
  const text = await res.text().catch(() => '')
  let json = null
  if (text) {
    try { json = JSON.parse(text) } catch { json = null }
  }

  if (!res.ok) {
    const err = new Error(`Yassir API error (${res.status})`)
    err.status = res.status
    err.body = json ?? text
    if (String(process.env.YASSIR_DEBUG || '').trim()) {
      const safePreview = body && typeof body === 'object'
        ? {
            countryCode: body.countryCode,
            actionCountryCode: body.actionCountryCode,
            currencyCode: body.currencyCode,
            actionCurrencyCode: body.actionCurrencyCode,
            amount: body.amount,
            merchantTransactionId: body.merchantTransactionId,
            actionId: body.actionId,
            customerId: body.customerId,
            userId: body.userId,
          }
        : undefined
      err.request = {
        method,
        url: u.toString(),
        bodyKeys: body && typeof body === 'object' ? Object.keys(body) : undefined,
        headersPreview: {
          'x-platform': headers['x-platform'],
          'x-service': headers['x-service'],
          'x-country-code': headers['x-country-code'],
          'x-sdk-version': headers['x-sdk-version'],
        },
        preview: safePreview,
      }
    }
    throw err
  }

  return json ?? {}
}

function normalizePhoneE164(v) {
  const raw = String(v || '').trim()
  if (!raw) return ''
  if (raw.startsWith('+')) return raw.replace(/\s+/g, '')
  const digits = raw.replace(/[^\d]/g, '')
  return digits ? `+${digits}` : ''
}

function normalizeCustomerResponse(v) {
  if (!v || typeof v !== 'object') return v
  if (v.id) return v
  if (v.customer && typeof v.customer === 'object') {
    if (v.customer.id) return v.customer
    if (v.customer.customerId) return { ...v.customer, id: v.customer.customerId }
  }
  if (v.data && typeof v.data === 'object') {
    if (v.data.id) return v.data
    if (v.data.customerId) return { ...v.data, id: v.data.customerId }
  }
  if (v.result && typeof v.result === 'object') {
    if (v.result.id) return v.result
    if (v.result.customerId) return { ...v.result, id: v.result.customerId }
  }
  if (v.customerId) return { ...v, id: v.customerId }
  if (v.customer_id) return { ...v, id: v.customer_id }
  return v
}

async function ensureCustomer({ phoneE164, email, firstName, lastName }) {
  const phone = normalizePhoneE164(phoneE164)
  if (!phone) throw new Error('phoneE164 is required')

  const isNotFound = (e) => {
    const status = e && e.status
    const body = e && e.body
    const msg =
      (body && typeof body === 'object' && body.message ? String(body.message) : '') ||
      (e && e.message ? String(e.message) : '')
    if (status === 404) return true
    if (status === 400 && /not found/i.test(msg)) return true
    return false
  }

  try {
    const found = await yassirRequest('GET', `/api/v1/customers/search/${encodeURIComponent(phone)}`)
    return normalizeCustomerResponse(found)
  } catch (e) {
    if (isNotFound(e)) {
      const name = `${String(firstName || '').trim()} ${String(lastName || '').trim()}`.trim()
      const created = await yassirRequest('POST', `/api/v1/customers`, {
        body: {
          phone,
          name: name || undefined,
          email: email || undefined,
          firstName: firstName || undefined,
          lastName: lastName || undefined,
        },
      })
      return normalizeCustomerResponse(created)
    }
    throw e
  }
}

async function listPaymentMethods({ country }) {
  const c = iso2ToIso3(country)
  return yassirRequest('GET', `/api/v1/payment-methods/available`, {
    query: { countryCode: c || undefined },
  })
}

async function createPaymentIntent({ phoneE164, country, amountCents, currency, merchantTransactionId, description, callbackUrl, successRedirectUrl, failRedirectUrl }) {
  const countryCode = iso2ToIso3(country)
  if (!countryCode) throw new Error('countryCode is required')
  const actionId = String(merchantTransactionId ?? '').trim()
  const actionCurrencyCode = String(currency ?? '').trim().toUpperCase()
  const actionCountryCode = String(countryCode).trim()
  const amountMajor = amountCents != null ? Number(amountCents) / 100 : NaN
  const amount = Number.isFinite(amountMajor) ? Math.round(amountMajor * 100) / 100 : undefined
  const body = {
    actionCountryCode: actionCountryCode || undefined,
    actionCurrencyCode: actionCurrencyCode || undefined,
    actionId: actionId || undefined,
    amount,
    userId: String(phoneE164 || '').trim() || undefined,
  }
  return yassirRequest('POST', `/api/v1/payments/intents`, { query: { countryCode }, body })
}

async function proceedIntent({ intentId, clientSecret, paymentMethodCode, paymentMethodId, msisdn, otp, countryCode, locale }) {
  const extraHeaders = {}
  if (clientSecret) extraHeaders['x-client-secret'] = clientSecret
  if (locale) extraHeaders['x-locale'] = locale
  if (countryCode) extraHeaders['x-country-code'] = countryCode

  const body = {
    ...(paymentMethodCode ? { paymentMethodCode, paymentMethod: paymentMethodCode } : {}),
    ...(paymentMethodId ? { paymentMethodId } : {}),
    ...(msisdn ? { msisdn } : {}),
    ...(otp ? { otp } : {}),
  }
  return yassirRequest('POST', `/api/v1/payments/intents/${encodeURIComponent(intentId)}/proceed`, { body, extraHeaders })
}

async function checkIntent({ intentId, clientSecret }) {
  const extraHeaders = {}
  if (clientSecret) extraHeaders['x-client-secret'] = clientSecret
  return yassirRequest('GET', `/api/v1/payments/intents/${encodeURIComponent(intentId)}/check`, {
    baseUrlOverride: getCheckBaseUrl(),
    extraHeaders,
  })
}

module.exports = {
  getBaseUrl,
  yassirRequest,
  ensureCustomer,
  listPaymentMethods,
  createPaymentIntent,
  proceedIntent,
  checkIntent,
  normalizePhoneE164,
}
